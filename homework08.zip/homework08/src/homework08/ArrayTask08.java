package homework08;

import java.util.Scanner;

// 8번 : 
public class ArrayTask08 {
//	8. 5개의 정수를 입력받은 뒤 그 값을 배열에 담고 최대값과 최소값 출력
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
		int[] arr = new int[5];
		// 최대값, 최소값을 담을 변수 
		int max = 0, min = 0;
		
		
		// 배열에 값 담기
		for(int i = 0; i < 5; i++) {
			// 정수 입력 메세지
			System.out.printf("정수를 입력하세요 : ");
			arr[i] = );
			
			if(arr[i] > max) {
				max = arr[i];
			}
			if(arr[i] < min) {
				min = arr[i];
			}
			
			
		}
		
		// 출력메세지
		System.out.println("최대값과 최소값을 출력합니다.");
		// 배열 값 출력하기
		System.out.printf("최대값 : %d, 최소값 : %d", max, min);
		
	}
}


